﻿namespace WindowsFormsApp1
{
    partial class RegisterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RegisterForm));
            this.Login = new System.Windows.Forms.Label();
            this.close_button = new System.Windows.Forms.Button();
            this.register_showpass = new System.Windows.Forms.Panel();
            this.register_pass = new System.Windows.Forms.CheckBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.cpassword = new System.Windows.Forms.TextBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Register_button = new System.Windows.Forms.Button();
            this.password = new System.Windows.Forms.TextBox();
            this.register_username = new System.Windows.Forms.TextBox();
            this.Register_Account = new System.Windows.Forms.Label();
            this.register_showpass.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // Login
            // 
            this.Login.AutoSize = true;
            this.Login.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Login.ForeColor = System.Drawing.Color.Teal;
            this.Login.Location = new System.Drawing.Point(366, 342);
            this.Login.Name = "Login";
            this.Login.Size = new System.Drawing.Size(111, 24);
            this.Login.TabIndex = 5;
            this.Login.Text = "Sign in here";
            this.Login.Click += new System.EventHandler(this.Login_Click);
            // 
            // close_button
            // 
            this.close_button.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.close_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.close_button.FlatAppearance.BorderColor = System.Drawing.Color.IndianRed;
            this.close_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.close_button.ForeColor = System.Drawing.Color.White;
            this.close_button.Location = new System.Drawing.Point(649, 12);
            this.close_button.Name = "close_button";
            this.close_button.Size = new System.Drawing.Size(60, 28);
            this.close_button.TabIndex = 5;
            this.close_button.Text = " X";
            this.close_button.UseVisualStyleBackColor = false;
            this.close_button.Click += new System.EventHandler(this.close_button_Click);
            // 
            // register_showpass
            // 
            this.register_showpass.BackColor = System.Drawing.Color.White;
            this.register_showpass.Controls.Add(this.register_pass);
            this.register_showpass.Controls.Add(this.pictureBox3);
            this.register_showpass.Controls.Add(this.cpassword);
            this.register_showpass.Controls.Add(this.pictureBox2);
            this.register_showpass.Controls.Add(this.pictureBox1);
            this.register_showpass.Controls.Add(this.Login);
            this.register_showpass.Controls.Add(this.label1);
            this.register_showpass.Controls.Add(this.Register_button);
            this.register_showpass.Controls.Add(this.password);
            this.register_showpass.Controls.Add(this.register_username);
            this.register_showpass.Controls.Add(this.Register_Account);
            this.register_showpass.Location = new System.Drawing.Point(57, 48);
            this.register_showpass.Name = "register_showpass";
            this.register_showpass.Size = new System.Drawing.Size(598, 384);
            this.register_showpass.TabIndex = 4;
            this.register_showpass.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // register_pass
            // 
            this.register_pass.AutoSize = true;
            this.register_pass.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.register_pass.Location = new System.Drawing.Point(281, 260);
            this.register_pass.Name = "register_pass";
            this.register_pass.Size = new System.Drawing.Size(144, 24);
            this.register_pass.TabIndex = 10;
            this.register_pass.Text = "Show Password";
            this.register_pass.UseVisualStyleBackColor = true;
            this.register_pass.CheckedChanged += new System.EventHandler(this.register_pass_CheckedChanged);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(121, 220);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(38, 30);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 9;
            this.pictureBox3.TabStop = false;
            // 
            // cpassword
            // 
            this.cpassword.Location = new System.Drawing.Point(185, 224);
            this.cpassword.Name = "cpassword";
            this.cpassword.Size = new System.Drawing.Size(240, 22);
            this.cpassword.TabIndex = 8;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(121, 180);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(38, 30);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 7;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(121, 139);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(38, 30);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(131, 342);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(216, 23);
            this.label1.TabIndex = 4;
            this.label1.Text = "Already have an account?";
            // 
            // Register_button
            // 
            this.Register_button.BackColor = System.Drawing.Color.Teal;
            this.Register_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Register_button.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Register_button.ForeColor = System.Drawing.Color.AliceBlue;
            this.Register_button.Location = new System.Drawing.Point(228, 290);
            this.Register_button.Name = "Register_button";
            this.Register_button.Size = new System.Drawing.Size(135, 49);
            this.Register_button.TabIndex = 3;
            this.Register_button.Text = "Register";
            this.Register_button.UseVisualStyleBackColor = false;
            this.Register_button.Click += new System.EventHandler(this.Register_button_Click);
            // 
            // password
            // 
            this.password.Location = new System.Drawing.Point(185, 184);
            this.password.Name = "password";
            this.password.Size = new System.Drawing.Size(240, 22);
            this.password.TabIndex = 2;
            // 
            // register_username
            // 
            this.register_username.Location = new System.Drawing.Point(185, 142);
            this.register_username.Name = "register_username";
            this.register_username.Size = new System.Drawing.Size(240, 22);
            this.register_username.TabIndex = 1;
            // 
            // Register_Account
            // 
            this.Register_Account.AutoSize = true;
            this.Register_Account.Font = new System.Drawing.Font("Microsoft YaHei UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Register_Account.Location = new System.Drawing.Point(178, 79);
            this.Register_Account.Name = "Register_Account";
            this.Register_Account.Size = new System.Drawing.Size(257, 37);
            this.Register_Account.TabIndex = 0;
            this.Register_Account.Text = "Register Account";
            // 
            // RegisterForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Teal;
            this.ClientSize = new System.Drawing.Size(716, 480);
            this.Controls.Add(this.close_button);
            this.Controls.Add(this.register_showpass);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "RegisterForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "RegisterForm";
            this.Load += new System.EventHandler(this.RegisterForm_Load);
            this.register_showpass.ResumeLayout(false);
            this.register_showpass.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label Login;
        private System.Windows.Forms.Button close_button;
        private System.Windows.Forms.Panel register_showpass;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.TextBox cpassword;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Register_button;
        private System.Windows.Forms.TextBox password;
        private System.Windows.Forms.TextBox register_username;
        private System.Windows.Forms.Label Register_Account;
        private System.Windows.Forms.CheckBox register_pass;
    }
}