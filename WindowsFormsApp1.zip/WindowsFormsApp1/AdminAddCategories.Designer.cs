﻿namespace WindowsFormsApp1
{
    partial class AdminAddCategories
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel9 = new System.Windows.Forms.Panel();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.label12 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.addCategories_category = new System.Windows.Forms.TextBox();
            this.addCategory_addBtn = new System.Windows.Forms.Button();
            this.addCategory_updateBtn = new System.Windows.Forms.Button();
            this.addCategory_deleteBtn = new System.Windows.Forms.Button();
            this.addCategory_removeBtn = new System.Windows.Forms.Button();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.panel10.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.White;
            this.panel9.Controls.Add(this.dataGridView2);
            this.panel9.Controls.Add(this.label12);
            this.panel9.Location = new System.Drawing.Point(282, 3);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(598, 638);
            this.panel9.TabIndex = 19;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.Teal;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(16, 140);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(554, 456);
            this.dataGridView2.TabIndex = 13;
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(29, 89);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(148, 25);
            this.label12.TabIndex = 12;
            this.label12.Text = "All Categories";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(27, 103);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(100, 25);
            this.label16.TabIndex = 0;
            this.label16.Text = "Category";
            // 
            // addCategories_category
            // 
            this.addCategories_category.Location = new System.Drawing.Point(31, 142);
            this.addCategories_category.Name = "addCategories_category";
            this.addCategories_category.Size = new System.Drawing.Size(211, 22);
            this.addCategories_category.TabIndex = 1;
            // 
            // addCategory_addBtn
            // 
            this.addCategory_addBtn.BackColor = System.Drawing.Color.Teal;
            this.addCategory_addBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.Teal;
            this.addCategory_addBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Teal;
            this.addCategory_addBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Teal;
            this.addCategory_addBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addCategory_addBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addCategory_addBtn.ForeColor = System.Drawing.Color.White;
            this.addCategory_addBtn.Location = new System.Drawing.Point(16, 208);
            this.addCategory_addBtn.Name = "addCategory_addBtn";
            this.addCategory_addBtn.Size = new System.Drawing.Size(115, 50);
            this.addCategory_addBtn.TabIndex = 8;
            this.addCategory_addBtn.Text = "Add";
            this.addCategory_addBtn.UseVisualStyleBackColor = false;
            this.addCategory_addBtn.Click += new System.EventHandler(this.addCategory_addBtn_Click);
            // 
            // addCategory_updateBtn
            // 
            this.addCategory_updateBtn.BackColor = System.Drawing.Color.Teal;
            this.addCategory_updateBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.Teal;
            this.addCategory_updateBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Teal;
            this.addCategory_updateBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Teal;
            this.addCategory_updateBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addCategory_updateBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addCategory_updateBtn.ForeColor = System.Drawing.Color.White;
            this.addCategory_updateBtn.Location = new System.Drawing.Point(139, 208);
            this.addCategory_updateBtn.Name = "addCategory_updateBtn";
            this.addCategory_updateBtn.Size = new System.Drawing.Size(118, 50);
            this.addCategory_updateBtn.TabIndex = 9;
            this.addCategory_updateBtn.Text = "Update";
            this.addCategory_updateBtn.UseVisualStyleBackColor = false;
            this.addCategory_updateBtn.Click += new System.EventHandler(this.addCategory_updateBtn_Click);
            // 
            // addCategory_deleteBtn
            // 
            this.addCategory_deleteBtn.BackColor = System.Drawing.Color.Teal;
            this.addCategory_deleteBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.Teal;
            this.addCategory_deleteBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Teal;
            this.addCategory_deleteBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Teal;
            this.addCategory_deleteBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addCategory_deleteBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addCategory_deleteBtn.ForeColor = System.Drawing.Color.White;
            this.addCategory_deleteBtn.Location = new System.Drawing.Point(15, 288);
            this.addCategory_deleteBtn.Name = "addCategory_deleteBtn";
            this.addCategory_deleteBtn.Size = new System.Drawing.Size(118, 50);
            this.addCategory_deleteBtn.TabIndex = 10;
            this.addCategory_deleteBtn.Text = "Delete";
            this.addCategory_deleteBtn.UseVisualStyleBackColor = false;
            this.addCategory_deleteBtn.Click += new System.EventHandler(this.addCategory_deleteBtn_Click);
            // 
            // addCategory_removeBtn
            // 
            this.addCategory_removeBtn.BackColor = System.Drawing.Color.Teal;
            this.addCategory_removeBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.Teal;
            this.addCategory_removeBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Teal;
            this.addCategory_removeBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Teal;
            this.addCategory_removeBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addCategory_removeBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addCategory_removeBtn.ForeColor = System.Drawing.Color.White;
            this.addCategory_removeBtn.Location = new System.Drawing.Point(142, 288);
            this.addCategory_removeBtn.Name = "addCategory_removeBtn";
            this.addCategory_removeBtn.Size = new System.Drawing.Size(115, 50);
            this.addCategory_removeBtn.TabIndex = 11;
            this.addCategory_removeBtn.Text = "Clear";
            this.addCategory_removeBtn.UseVisualStyleBackColor = false;
            this.addCategory_removeBtn.Click += new System.EventHandler(this.addCategory_removeBtn_Click);
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.White;
            this.panel10.Controls.Add(this.addCategory_removeBtn);
            this.panel10.Controls.Add(this.addCategory_deleteBtn);
            this.panel10.Controls.Add(this.addCategory_updateBtn);
            this.panel10.Controls.Add(this.addCategory_addBtn);
            this.panel10.Controls.Add(this.addCategories_category);
            this.panel10.Controls.Add(this.label16);
            this.panel10.Location = new System.Drawing.Point(0, 2);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(273, 638);
            this.panel10.TabIndex = 20;
            // 
            // AdminAddCategories
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Teal;
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.panel9);
            this.Name = "AdminAddCategories";
            this.Size = new System.Drawing.Size(880, 641);
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox addCategories_category;
        private System.Windows.Forms.Button addCategory_addBtn;
        private System.Windows.Forms.Button addCategory_updateBtn;
        private System.Windows.Forms.Button addCategory_deleteBtn;
        private System.Windows.Forms.Button addCategory_removeBtn;
        private System.Windows.Forms.Panel panel10;
    }
}
