﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class MainForm : Form
    {
        private object user_Username;

        public MainForm()
        {
            InitializeComponent();
           
        }
        
        private void close_Click_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to close?", "Confirmation Message"
                                  , MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void logout_button_Click(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel6_Paint(object sender, PaintEventArgs e)
        {

        }

        private void logout_button_Click_1(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to logout?", "Confirmation Message",
                         MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Hide(); // Hide the current form (Dashboard or Main form)

                Form1 loginForm = new Form1();
                loginForm.Show(); // Show the login form again
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void adminAdduser1_Load(object sender, EventArgs e)
        {

        }

        private void adminAdduser2_Load(object sender, EventArgs e)
        {

        }

        private void adminAdduser1_Load_1(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void dashboard_btn_Click(object sender, EventArgs e)
        {
            adminDashboard1.BringToFront();
            adminDashboard1.Visible = true;
            adminAdduser1.Visible = false;
            adminAddCategories1.Visible = false;
            adminAddProducts1.Visible = false;
            cashierCustomersForm1.Visible = false;
            
AdminDashboard adForm = adminDashboard1 as AdminDashboard;

            if (adForm != null)
            {
                adForm.refreshData();
            }


        }

        private void addUsers_btn_Click(object sender, EventArgs e)
        {
            adminAdduser1.BringToFront();
            adminDashboard1.Visible = false;
            adminAdduser1.Visible = true;
            adminAddCategories1.Visible = false;
            adminAddProducts1.Visible = false;
            cashierCustomersForm1.Visible = false;
            AdminAdduser aauForm = adminAdduser1 as AdminAdduser;

            if (aauForm != null)
            {
                aauForm.refreshData();
            }
        }

        private void addcategories_btn_Click(object sender, EventArgs e)
        {
            adminAddCategories1.BringToFront(); 
            adminDashboard1.Visible = false;
            adminAdduser1.Visible = false;
            adminAddCategories1.Visible = true;
            adminAddProducts1.Visible = false;
            cashierCustomersForm1.Visible = false;
            AdminAddCategories aacForm = adminAddCategories1 as AdminAddCategories;

            if (aacForm != null)
            {
                aacForm.refreshData();
            }
        }

        private void addProducts_btn_Click(object sender, EventArgs e)
        {
            adminAddProducts1.BringToFront(); 
            adminDashboard1.Visible = false;
            adminAdduser1.Visible = false;
            adminAddCategories1.Visible = false;
            adminAddProducts1.Visible = true;
            cashierCustomersForm1.Visible = false;
            AdminAddProducts aapForm = adminAddProducts1 as AdminAddProducts;

            if (aapForm != null)
            {
                aapForm.refreshData();
            }
        }

        private void customers_btn_Click(object sender, EventArgs e)
        {
            cashierCustomersForm1.BringToFront();
            adminDashboard1.Visible = false;
            adminAdduser1.Visible = false;
            adminAddCategories1.Visible = false;
            adminAddProducts1.Visible = false;
            cashierCustomersForm1.Visible = true;
            CashierCustomersForm ccfForm = cashierCustomersForm1 as CashierCustomersForm;

            if (ccfForm != null)
            {
                ccfForm.refreshData();
            }
        }
    }
}

