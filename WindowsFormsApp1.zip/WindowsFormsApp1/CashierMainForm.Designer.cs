﻿namespace WindowsFormsApp1
{
    partial class CashierMainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CashierMainForm));
            this.panel1 = new System.Windows.Forms.Panel();
            this.System_Name = new System.Windows.Forms.Label();
            this.close_Click = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.logout_btn = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.user_username1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.cashierOrder1 = new WindowsFormsApp1.CashierOrder();
            this.cashierCustomersForm1 = new WindowsFormsApp1.CashierCustomersForm();
            this.adminAddProducts1 = new WindowsFormsApp1.AdminAddProducts();
            this.adminDashboard1 = new WindowsFormsApp1.AdminDashboard();
            this.dashboard_btn = new System.Windows.Forms.Label();
            this.addproducts_btn = new System.Windows.Forms.Label();
            this.customers_btn = new System.Windows.Forms.Label();
            this.order_btn = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.CadetBlue;
            this.panel1.Controls.Add(this.System_Name);
            this.panel1.Controls.Add(this.close_Click);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1131, 48);
            this.panel1.TabIndex = 1;
            // 
            // System_Name
            // 
            this.System_Name.AutoSize = true;
            this.System_Name.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.System_Name.ForeColor = System.Drawing.Color.Black;
            this.System_Name.Location = new System.Drawing.Point(12, 7);
            this.System_Name.Name = "System_Name";
            this.System_Name.Size = new System.Drawing.Size(387, 31);
            this.System_Name.TabIndex = 5;
            this.System_Name.Text = "PaperTrail POS | Cashier\'s Portal";
            // 
            // close_Click
            // 
            this.close_Click.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.close_Click.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.close_Click.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.close_Click.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.close_Click.ForeColor = System.Drawing.Color.White;
            this.close_Click.Location = new System.Drawing.Point(1059, 10);
            this.close_Click.Name = "close_Click";
            this.close_Click.Size = new System.Drawing.Size(60, 28);
            this.close_Click.TabIndex = 4;
            this.close_Click.Text = " X";
            this.close_Click.UseVisualStyleBackColor = false;
            this.close_Click.Click += new System.EventHandler(this.close_Click_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Teal;
            this.panel2.Controls.Add(this.order_btn);
            this.panel2.Controls.Add(this.customers_btn);
            this.panel2.Controls.Add(this.addproducts_btn);
            this.panel2.Controls.Add(this.dashboard_btn);
            this.panel2.Controls.Add(this.logout_btn);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.user_username1);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 48);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(239, 648);
            this.panel2.TabIndex = 2;
            // 
            // logout_btn
            // 
            this.logout_btn.AutoSize = true;
            this.logout_btn.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logout_btn.ForeColor = System.Drawing.Color.White;
            this.logout_btn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.logout_btn.Location = new System.Drawing.Point(58, 597);
            this.logout_btn.Name = "logout_btn";
            this.logout_btn.Size = new System.Drawing.Size(97, 31);
            this.logout_btn.TabIndex = 14;
            this.logout_btn.Text = "Logout";
            this.logout_btn.Click += new System.EventHandler(this.logout_btn_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label6.Location = new System.Drawing.Point(36, 394);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(0, 27);
            this.label6.TabIndex = 12;
            // 
            // user_username1
            // 
            this.user_username1.AutoSize = true;
            this.user_username1.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.user_username1.ForeColor = System.Drawing.Color.White;
            this.user_username1.Location = new System.Drawing.Point(12, 191);
            this.user_username1.Name = "user_username1";
            this.user_username1.Size = new System.Drawing.Size(181, 31);
            this.user_username1.TabIndex = 6;
            this.user_username1.Text = "Welcome User";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(48, 37);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(140, 135);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // cashierOrder1
            // 
            this.cashierOrder1.BackColor = System.Drawing.Color.Teal;
            this.cashierOrder1.Location = new System.Drawing.Point(239, 48);
            this.cashierOrder1.Name = "cashierOrder1";
            this.cashierOrder1.Size = new System.Drawing.Size(892, 648);
            this.cashierOrder1.TabIndex = 3;
            // 
            // cashierCustomersForm1
            // 
            this.cashierCustomersForm1.BackColor = System.Drawing.Color.Teal;
            this.cashierCustomersForm1.Location = new System.Drawing.Point(239, 48);
            this.cashierCustomersForm1.Name = "cashierCustomersForm1";
            this.cashierCustomersForm1.Size = new System.Drawing.Size(892, 645);
            this.cashierCustomersForm1.TabIndex = 4;
            // 
            // adminAddProducts1
            // 
            this.adminAddProducts1.BackColor = System.Drawing.Color.Teal;
            this.adminAddProducts1.Location = new System.Drawing.Point(239, 51);
            this.adminAddProducts1.Name = "adminAddProducts1";
            this.adminAddProducts1.Size = new System.Drawing.Size(892, 645);
            this.adminAddProducts1.TabIndex = 5;
            // 
            // adminDashboard1
            // 
            this.adminDashboard1.BackColor = System.Drawing.Color.Ivory;
            this.adminDashboard1.Location = new System.Drawing.Point(244, 57);
            this.adminDashboard1.Name = "adminDashboard1";
            this.adminDashboard1.Size = new System.Drawing.Size(880, 630);
            this.adminDashboard1.TabIndex = 6;
            // 
            // dashboard_btn
            // 
            this.dashboard_btn.AutoSize = true;
            this.dashboard_btn.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dashboard_btn.ForeColor = System.Drawing.Color.White;
            this.dashboard_btn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.dashboard_btn.Location = new System.Drawing.Point(35, 287);
            this.dashboard_btn.Name = "dashboard_btn";
            this.dashboard_btn.Size = new System.Drawing.Size(139, 31);
            this.dashboard_btn.TabIndex = 15;
            this.dashboard_btn.Text = "Dashboard";
            this.dashboard_btn.Click += new System.EventHandler(this.dashboard_btn_Click_1);
            // 
            // addproducts_btn
            // 
            this.addproducts_btn.AutoSize = true;
            this.addproducts_btn.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addproducts_btn.ForeColor = System.Drawing.Color.White;
            this.addproducts_btn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.addproducts_btn.Location = new System.Drawing.Point(12, 339);
            this.addproducts_btn.Name = "addproducts_btn";
            this.addproducts_btn.Size = new System.Drawing.Size(171, 31);
            this.addproducts_btn.TabIndex = 16;
            this.addproducts_btn.Text = "Add Products";
            this.addproducts_btn.Click += new System.EventHandler(this.addproducts_btn_Click);
            // 
            // customers_btn
            // 
            this.customers_btn.AutoSize = true;
            this.customers_btn.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customers_btn.ForeColor = System.Drawing.Color.White;
            this.customers_btn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.customers_btn.Location = new System.Drawing.Point(26, 390);
            this.customers_btn.Name = "customers_btn";
            this.customers_btn.Size = new System.Drawing.Size(137, 31);
            this.customers_btn.TabIndex = 17;
            this.customers_btn.Text = "Customers";
            this.customers_btn.Click += new System.EventHandler(this.customers_btn_Click);
            // 
            // order_btn
            // 
            this.order_btn.AutoSize = true;
            this.order_btn.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.order_btn.ForeColor = System.Drawing.Color.White;
            this.order_btn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.order_btn.Location = new System.Drawing.Point(42, 439);
            this.order_btn.Name = "order_btn";
            this.order_btn.Size = new System.Drawing.Size(81, 31);
            this.order_btn.TabIndex = 18;
            this.order_btn.Text = "Order";
            this.order_btn.Click += new System.EventHandler(this.order_btn_Click);
            // 
            // CashierMainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1131, 696);
            this.Controls.Add(this.adminDashboard1);
            this.Controls.Add(this.adminAddProducts1);
            this.Controls.Add(this.cashierCustomersForm1);
            this.Controls.Add(this.cashierOrder1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "CashierMainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CashierMainForm";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label System_Name;
        private System.Windows.Forms.Button close_Click;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label logout_btn;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label user_username1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private CashierOrder cashierOrder1;
        private CashierCustomersForm cashierCustomersForm1;
        private AdminAddProducts adminAddProducts1;
        private AdminDashboard adminDashboard1;
        private System.Windows.Forms.Label order_btn;
        private System.Windows.Forms.Label customers_btn;
        private System.Windows.Forms.Label addproducts_btn;
        private System.Windows.Forms.Label dashboard_btn;
    }
}