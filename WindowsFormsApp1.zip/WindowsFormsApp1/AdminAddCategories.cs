﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class AdminAddCategories : UserControl
    {
        SqlConnection
           connect = new SqlConnection(@"Data Source=DESKTOP-CVFUKU0\SQLEXPRESS01;
                                           Initial Catalog=Stationary Shop;
                                           Integrated Security=True;
                                           Encrypt=False;");
        public AdminAddCategories()
        {
            InitializeComponent();
            displayCategoriesData();
        }
        public void refreshData()
        {
            if (InvokeRequired)
            {
                Invoke((MethodInvoker)refreshData);
                return;
            }
            displayCategoriesData();
        }
        public void displayCategoriesData()
        {
            CategoriesData cData = new CategoriesData();
            List<CategoriesData> listData = cData.AllCategoriesData();
            dataGridView2.DataSource = listData;
        }

        private void addCategory_addBtn_Click(object sender, EventArgs e)
        {
            if (addCategories_category.Text == "")
            {
                MessageBox.Show("Empty fields", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (checkConnection())
                {
                    try
                    {
                        connect.Open();
                        string checkCat = "SELECT * FROM categories WHERE category = @cat";
                        using (SqlCommand cmd = new SqlCommand(checkCat, connect))
                        {
                            cmd.Parameters.AddWithValue("@cat", addCategories_category.Text.Trim());
                            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                            DataTable table = new DataTable();
                            adapter.Fill(table);
                            if (table.Rows.Count > 0)
                            {
                                MessageBox.Show("Category: " + addCategories_category.Text.Trim() + " is already ex", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                            else
                            {
                                string insertData = "INSERT INTO categories (category, date) VALUES(@cat, @date)";
                                using (SqlCommand insertD = new SqlCommand(insertData, connect))
                                {
                                    insertD.Parameters.AddWithValue("@cat", addCategories_category.Text.Trim());
                                    DateTime today = DateTime.Today;
                                    insertD.Parameters.AddWithValue("@date", today);
                                    insertD.ExecuteNonQuery();
                                    clearFields();
                                    displayCategoriesData();
                                    MessageBox.Show("Added successfully!", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                }
                            }
                        }
                    }

                    catch (Exception ex)
                    {
                        MessageBox.Show("Connection failed: " + ex, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    finally
                    {
                        connect.Close();
                    }
                }
            }
        }
        public bool checkConnection()
        {
            if (connect.State == ConnectionState.Closed)
            {
                return true;

            }
            else
            {
                return false;
            }
        }
        public void clearFields()
        {
            addCategories_category.Text = "";
        }
        private void addCategory_removeBtn_Click(object sender, EventArgs e)
        {
            clearFields();
        }
        private int getID = 0;
        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                DataGridViewRow row = dataGridView2.Rows[e.RowIndex];


                getID = (int)row.Cells[0].Value;
                addCategories_category.Text = row.Cells[1].Value.ToString();
            }

        }

        private void addCategory_updateBtn_Click(object sender, EventArgs e)
        {
            if (addCategories_category.Text == "")
            {
                MessageBox.Show("Empty fields", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                {
                    if (MessageBox.Show("Are you sure you want to Update Cat ID: " + getID + "?", "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        if (checkConnection())
                        {
                            try
                            {
                                connect.Open();

                                string updateData = "Update categories SET category = @cat Where id = @id";
                                using (SqlCommand updateD = new SqlCommand(updateData, connect))
                                {
                                    updateD.Parameters.AddWithValue("@cat", addCategories_category.Text.Trim());
                                    updateD.Parameters.AddWithValue("@id", getID);

                                    updateD.ExecuteNonQuery();
                                    clearFields();
                                    displayCategoriesData();
                                    MessageBox.Show("Updated successfully!", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                }
                            }

                            catch (Exception ex)
                            {
                                MessageBox.Show("Connection failed: " + ex, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                            finally
                            {
                                connect.Close();
                            }
                        }
                }

            }
        }

        private void addCategory_deleteBtn_Click(object sender, EventArgs e)
        {
            if (addCategories_category.Text == "")
            {
                MessageBox.Show("Empty fields", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                {
                    if (MessageBox.Show("Are you sure you want to Delete Cat ID: " + getID + "?", "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        if (checkConnection())
                        {
                            try
                            {
                                connect.Open();

                                string removeData = "DELETE FROM categories WHERE id = @id";
                                using (SqlCommand DeleteD = new SqlCommand(removeData, connect))
                                {
                                    DeleteD.Parameters.AddWithValue("@id", getID);
                                    DeleteD.ExecuteNonQuery();
                                    clearFields();
                                    displayCategoriesData();
                                    MessageBox.Show("Remove successfully!", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                }
                            }

                            catch (Exception ex)
                            {
                                MessageBox.Show("Connection failed: " + ex, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                            finally
                            {
                                connect.Close();
                            }
                        }
                }

            }

        }
    }
}
