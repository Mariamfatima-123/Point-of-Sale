﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class AdminAddProducts : UserControl
    {
        SqlConnection
           connect = new SqlConnection(@"Data Source=DESKTOP-CVFUKU0\SQLEXPRESS01;
                                           Initial Catalog=Stationary Shop;
                                           Integrated Security=True;
                                           Encrypt=False;");
        public AdminAddProducts()
        {
            InitializeComponent();
            displayCategories();
            displayAllProducts();
        }
        public void refreshData()
        {
            if (InvokeRequired)
            {
                Invoke((MethodInvoker)refreshData);
                return;
            }
            displayCategories();
            displayAllProducts();
        }
        public void displayAllProducts()
        {
            AddProductsData apData = new AddProductsData();
            List<AddProductsData> listData = apData.AllproductsData();
            dataGridView1.DataSource = listData;
        }

        public bool emptyFields()
        {
            if (addProducts_prodID.Text == "" || addProduct_prodName.Text == "" || addProducts_category.SelectedIndex == -1
                || addProduct_price.Text == "" || addProducts_stock.Text == "" || addProduct_status.SelectedIndex == -1
                )
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public void displayCategories()
        {
            if (checkConnection())
            {
                try
                {
                    connect.Open();

                    string selectData = "SELECT * FROM categories";

                    using (SqlCommand cmd = new SqlCommand(selectData, connect))
                    {
                        SqlDataReader reader = cmd.ExecuteReader();

                        if (reader.HasRows)
                        {
                            while (reader.Read())
                            {
                                addProducts_category.Items.Add(reader["category"].ToString());
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                }
                finally
                {
                    connect.Close();
                }
            }
        }
        public void clearFields()
        {
            addProducts_prodID.Text = "";
            addProduct_prodName.Text = "";
            addProducts_category.SelectedIndex = -1;
            addProduct_price.Text = "";
            addProducts_stock.Text = "";
            addProduct_status.SelectedIndex = -1;
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            clearFields();
        }

        private void addProducts_addBtn_Click(object sender, EventArgs e)
        {
            if (emptyFields())
            {
                MessageBox.Show("Empty Fields", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


            else
            {
                if (checkConnection())
                {
                    try
                    {
                        connect.Open();

                        string selectData = "SELECT * FROM products WHERE prod_id = @prodID";

                        using (SqlCommand cmd = new SqlCommand(selectData, connect))
                        {
                            cmd.Parameters.AddWithValue("@prodID", addProducts_prodID.Text.Trim());

                            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                            DataTable table = new DataTable();

                            adapter.Fill(table);

                            if (table.Rows.Count > 0)
                            {
                                MessageBox.Show("Product ID: " + addProducts_prodID.Text.Trim() + " is existing already", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                            else
                            {
                                string insertData = "INSERT INTO products " +
                                                    "(prod_id, prod_name, category, price, stock, status, date_insert) " +
                                                    "VALUES (@prodID, @prodName, @cat, @price, @stock,  @status, @date)";

                                using (SqlCommand insertD = new SqlCommand(insertData, connect))
                                {
                                    insertD.Parameters.AddWithValue("@prodID", addProducts_prodID.Text.Trim());
                                    insertD.Parameters.AddWithValue("@prodName", addProduct_prodName.Text.Trim());
                                    insertD.Parameters.AddWithValue("@cat", addProducts_category.SelectedItem);
                                    insertD.Parameters.AddWithValue("@price", addProduct_price.Text.Trim());
                                    insertD.Parameters.AddWithValue("@stock", addProducts_stock.Text.Trim());
                                    insertD.Parameters.AddWithValue("@status", addProduct_status.SelectedItem);



                                    DateTime today = DateTime.Today;
                                    insertD.Parameters.AddWithValue("@date", DateTime.Today);
                                    insertD.ExecuteNonQuery();
                                    clearFields();

                                    MessageBox.Show("Added successfully!", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    displayCategories();
                                    displayAllProducts();
                                }
                            }
                        }
                    }

                    catch (Exception ex)
                    {
                        MessageBox.Show("Failed connection: " + ex, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    finally
                    {
                        connect.Close();
                    }
                }
            }
        }
    
        public bool checkConnection()
        {
            if (connect.State == ConnectionState.Closed)
            {
                return true;

            }
            else
            {
                return false;
            }
        }

        private void addProducts_updateBtn_Click(object sender, EventArgs e)
        {
            if (emptyFields())
            {
                MessageBox.Show("Empty Fields", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }



            else
            {
                if (MessageBox.Show("Are you sure you want to Update Product ID: " + addProducts_prodID.Text.Trim() + "?", "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {


                    if (checkConnection())
                    {
                        try
                        {
                            connect.Open();




                            string updateData = "UPDATE products SET prod_id = @prodID, prod_name = @prodName" +
    ", category = @cat, price = @price, stock = @stock,  status = @status WHERE id = @id";

                            using (SqlCommand updateD = new SqlCommand(updateData, connect))
                            {
                                updateD.Parameters.AddWithValue("@prodID", addProducts_prodID.Text.Trim());
                                updateD.Parameters.AddWithValue("@prodName", addProduct_prodName.Text.Trim());
                                updateD.Parameters.AddWithValue("@cat", addProducts_category.SelectedItem);
                                updateD.Parameters.AddWithValue("@price", addProduct_price.Text.Trim());
                                updateD.Parameters.AddWithValue("@stock", addProducts_stock.Text.Trim());
                                updateD.Parameters.AddWithValue("@status", addProduct_status.SelectedItem);
                                updateD.Parameters.AddWithValue("@id", getID);



                                DateTime today = DateTime.Today;
                                updateD.Parameters.AddWithValue("@date", DateTime.Today);
                                updateD.ExecuteNonQuery();
                                clearFields();

                                MessageBox.Show("Updatedsuccessfully!", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                displayCategories();
                                displayAllProducts();
                            }
                        }

                        catch (Exception ex)
                        {
                            MessageBox.Show("Failed connection: " + ex, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        finally
                        {
                            connect.Close();
                        }
                    }
                }
            }
        }

        private void addProducts_removeBtn_Click(object sender, EventArgs e)
        {
            if (emptyFields())
            {
                MessageBox.Show("Empty Fields", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }



            else
            {
                if (MessageBox.Show("Are you sure you want to Delete Product ID: " + addProducts_prodID.Text.Trim() + "?", "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {


                    if (checkConnection())
                    {
                        try
                        {
                            connect.Open();

                            string deleteData = "Delete FROM Products WHERE id = @id";

                            using (SqlCommand deleteD = new SqlCommand(deleteData, connect))
                            {
                               
                                deleteD.Parameters.AddWithValue("@id", getID);



                                DateTime today = DateTime.Today;
                                deleteD.Parameters.AddWithValue("@date", DateTime.Today);
                                deleteD.ExecuteNonQuery();
                                clearFields();

                                MessageBox.Show("Deleted successfully!", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                displayCategories();
                                displayAllProducts();
                            }
                        }

                        catch (Exception ex)
                        {
                            MessageBox.Show("Failed connection: " + ex, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        finally
                        {
                            connect.Close();
                        }
                    }
                }
            }

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private int getID = 0;
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

getID = (int)row.Cells[0].Value; 
addProducts_prodID.Text = row.Cells[1].Value.ToString();
                addProduct_prodName.Text = row.Cells[2].Value.ToString();
                addProducts_category.Text = row.Cells[3].Value.ToString();
                addProduct_price.Text = row.Cells[4].Value.ToString();
                addProducts_stock.Text = row.Cells[5].Value.ToString();
                addProduct_status.Text = row.Cells[6].Value.ToString();
            }
        }

    }
}

