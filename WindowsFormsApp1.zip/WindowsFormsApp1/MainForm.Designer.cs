﻿namespace WindowsFormsApp1
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.panel1 = new System.Windows.Forms.Panel();
            this.System_Name = new System.Windows.Forms.Label();
            this.close_Click = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.logout_button = new System.Windows.Forms.Label();
            this.user_username1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dashboard_btn = new System.Windows.Forms.Label();
            this.addUsers_btn = new System.Windows.Forms.Label();
            this.addcategories_btn = new System.Windows.Forms.Label();
            this.customers_btn = new System.Windows.Forms.Label();
            this.addProducts_btn = new System.Windows.Forms.Label();
            this.adminDashboard1 = new WindowsFormsApp1.AdminDashboard();
            this.adminAdduser2 = new WindowsFormsApp1.AdminAdduser();
            this.adminAddCategories1 = new WindowsFormsApp1.AdminAddCategories();
            this.adminAddProducts1 = new WindowsFormsApp1.AdminAddProducts();
            this.cashierCustomersForm1 = new WindowsFormsApp1.CashierCustomersForm();
            this.adminAdduser1 = new WindowsFormsApp1.AdminAdduser();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.CadetBlue;
            this.panel1.Controls.Add(this.System_Name);
            this.panel1.Controls.Add(this.close_Click);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1131, 48);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // System_Name
            // 
            this.System_Name.AutoSize = true;
            this.System_Name.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.System_Name.ForeColor = System.Drawing.Color.Black;
            this.System_Name.Location = new System.Drawing.Point(12, 7);
            this.System_Name.Name = "System_Name";
            this.System_Name.Size = new System.Drawing.Size(380, 31);
            this.System_Name.TabIndex = 5;
            this.System_Name.Text = "PaperTrail POS | Admin\'s Portal";
            // 
            // close_Click
            // 
            this.close_Click.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.close_Click.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.close_Click.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.close_Click.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.close_Click.ForeColor = System.Drawing.Color.White;
            this.close_Click.Location = new System.Drawing.Point(1059, 10);
            this.close_Click.Name = "close_Click";
            this.close_Click.Size = new System.Drawing.Size(60, 28);
            this.close_Click.TabIndex = 4;
            this.close_Click.Text = " X";
            this.close_Click.UseVisualStyleBackColor = false;
            this.close_Click.Click += new System.EventHandler(this.close_Click_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Teal;
            this.panel2.Controls.Add(this.addProducts_btn);
            this.panel2.Controls.Add(this.customers_btn);
            this.panel2.Controls.Add(this.addcategories_btn);
            this.panel2.Controls.Add(this.addUsers_btn);
            this.panel2.Controls.Add(this.dashboard_btn);
            this.panel2.Controls.Add(this.logout_button);
            this.panel2.Controls.Add(this.user_username1);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 48);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(239, 648);
            this.panel2.TabIndex = 1;
            // 
            // logout_button
            // 
            this.logout_button.AutoSize = true;
            this.logout_button.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logout_button.ForeColor = System.Drawing.Color.White;
            this.logout_button.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.logout_button.Location = new System.Drawing.Point(58, 597);
            this.logout_button.Name = "logout_button";
            this.logout_button.Size = new System.Drawing.Size(97, 31);
            this.logout_button.TabIndex = 14;
            this.logout_button.Text = "Logout";
            this.logout_button.Click += new System.EventHandler(this.logout_button_Click_1);
            // 
            // user_username1
            // 
            this.user_username1.AutoSize = true;
            this.user_username1.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.user_username1.ForeColor = System.Drawing.Color.White;
            this.user_username1.Location = new System.Drawing.Point(12, 175);
            this.user_username1.Name = "user_username1";
            this.user_username1.Size = new System.Drawing.Size(206, 31);
            this.user_username1.TabIndex = 6;
            this.user_username1.Text = "Welcome Admin";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(48, 37);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(140, 135);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // dashboard_btn
            // 
            this.dashboard_btn.AutoSize = true;
            this.dashboard_btn.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dashboard_btn.ForeColor = System.Drawing.Color.White;
            this.dashboard_btn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.dashboard_btn.Location = new System.Drawing.Point(29, 259);
            this.dashboard_btn.Name = "dashboard_btn";
            this.dashboard_btn.Size = new System.Drawing.Size(139, 31);
            this.dashboard_btn.TabIndex = 15;
            this.dashboard_btn.Text = "Dashboard";
            this.dashboard_btn.Click += new System.EventHandler(this.dashboard_btn_Click);
            // 
            // addUsers_btn
            // 
            this.addUsers_btn.AutoSize = true;
            this.addUsers_btn.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addUsers_btn.ForeColor = System.Drawing.Color.White;
            this.addUsers_btn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.addUsers_btn.Location = new System.Drawing.Point(29, 309);
            this.addUsers_btn.Name = "addUsers_btn";
            this.addUsers_btn.Size = new System.Drawing.Size(131, 31);
            this.addUsers_btn.TabIndex = 16;
            this.addUsers_btn.Text = "Add Users";
            this.addUsers_btn.Click += new System.EventHandler(this.addUsers_btn_Click);
            // 
            // addcategories_btn
            // 
            this.addcategories_btn.AutoSize = true;
            this.addcategories_btn.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addcategories_btn.ForeColor = System.Drawing.Color.White;
            this.addcategories_btn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.addcategories_btn.Location = new System.Drawing.Point(12, 365);
            this.addcategories_btn.Name = "addcategories_btn";
            this.addcategories_btn.Size = new System.Drawing.Size(190, 31);
            this.addcategories_btn.TabIndex = 17;
            this.addcategories_btn.Text = "Add Categories";
            this.addcategories_btn.Click += new System.EventHandler(this.addcategories_btn_Click);
            // 
            // customers_btn
            // 
            this.customers_btn.AutoSize = true;
            this.customers_btn.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customers_btn.ForeColor = System.Drawing.Color.White;
            this.customers_btn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.customers_btn.Location = new System.Drawing.Point(29, 469);
            this.customers_btn.Name = "customers_btn";
            this.customers_btn.Size = new System.Drawing.Size(137, 31);
            this.customers_btn.TabIndex = 18;
            this.customers_btn.Text = "Customers";
            this.customers_btn.Click += new System.EventHandler(this.customers_btn_Click);
            // 
            // addProducts_btn
            // 
            this.addProducts_btn.AutoSize = true;
            this.addProducts_btn.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addProducts_btn.ForeColor = System.Drawing.Color.White;
            this.addProducts_btn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.addProducts_btn.Location = new System.Drawing.Point(17, 418);
            this.addProducts_btn.Name = "addProducts_btn";
            this.addProducts_btn.Size = new System.Drawing.Size(171, 31);
            this.addProducts_btn.TabIndex = 19;
            this.addProducts_btn.Text = "Add Products";
            this.addProducts_btn.Click += new System.EventHandler(this.addProducts_btn_Click);
            // 
            // adminDashboard1
            // 
            this.adminDashboard1.BackColor = System.Drawing.Color.Ivory;
            this.adminDashboard1.Location = new System.Drawing.Point(239, 48);
            this.adminDashboard1.Name = "adminDashboard1";
            this.adminDashboard1.Size = new System.Drawing.Size(887, 645);
            this.adminDashboard1.TabIndex = 6;
            // 
            // adminAdduser2
            // 
            this.adminAdduser2.BackColor = System.Drawing.Color.Teal;
            this.adminAdduser2.Location = new System.Drawing.Point(239, 52);
            this.adminAdduser2.Name = "adminAdduser2";
            this.adminAdduser2.Size = new System.Drawing.Size(885, 645);
            this.adminAdduser2.TabIndex = 5;
            // 
            // adminAddCategories1
            // 
            this.adminAddCategories1.BackColor = System.Drawing.Color.Teal;
            this.adminAddCategories1.Location = new System.Drawing.Point(242, 52);
            this.adminAddCategories1.Name = "adminAddCategories1";
            this.adminAddCategories1.Size = new System.Drawing.Size(880, 641);
            this.adminAddCategories1.TabIndex = 4;
            // 
            // adminAddProducts1
            // 
            this.adminAddProducts1.BackColor = System.Drawing.Color.Teal;
            this.adminAddProducts1.Location = new System.Drawing.Point(245, 48);
            this.adminAddProducts1.Name = "adminAddProducts1";
            this.adminAddProducts1.Size = new System.Drawing.Size(886, 648);
            this.adminAddProducts1.TabIndex = 3;
            // 
            // cashierCustomersForm1
            // 
            this.cashierCustomersForm1.BackColor = System.Drawing.Color.Teal;
            this.cashierCustomersForm1.Location = new System.Drawing.Point(237, 48);
            this.cashierCustomersForm1.Name = "cashierCustomersForm1";
            this.cashierCustomersForm1.Size = new System.Drawing.Size(894, 648);
            this.cashierCustomersForm1.TabIndex = 2;
            // 
            // adminAdduser1
            // 
            this.adminAdduser1.BackColor = System.Drawing.Color.Teal;
            this.adminAdduser1.Location = new System.Drawing.Point(241, 44);
            this.adminAdduser1.Name = "adminAdduser1";
            this.adminAdduser1.Size = new System.Drawing.Size(880, 652);
            this.adminAdduser1.TabIndex = 9;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1131, 696);
            this.Controls.Add(this.adminDashboard1);
            this.Controls.Add(this.adminAdduser2);
            this.Controls.Add(this.adminAddCategories1);
            this.Controls.Add(this.adminAddProducts1);
            this.Controls.Add(this.cashierCustomersForm1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MainForm";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label System_Name;
        private System.Windows.Forms.Button close_Click;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label user_username1;
        private System.Windows.Forms.Label logout_button;
        private AdminAdduser adminAdduser1;
        private CashierCustomersForm cashierCustomersForm1;
        private AdminAddProducts adminAddProducts1;
        private AdminAddCategories adminAddCategories1;
        private System.Windows.Forms.Label addProducts_btn;
        private System.Windows.Forms.Label customers_btn;
        private System.Windows.Forms.Label addcategories_btn;
        private System.Windows.Forms.Label addUsers_btn;
        private System.Windows.Forms.Label dashboard_btn;
        private AdminAdduser adminAdduser2;
        private AdminDashboard adminDashboard1;
    }
}