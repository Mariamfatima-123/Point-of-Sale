﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public static string username;
        SqlConnection connect = new SqlConnection(@"Data Source=DESKTOP-CVFUKU0\SQLEXPRESS01;
                                                    Initial Catalog=Stationary Shop;
                                                    Integrated Security=True;
                                                    Encrypt=False;");
        private object password;

        public Form1()
        {
            InitializeComponent();
            login_password.PasswordChar = '*';
        }

        private void close_button_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Register_Click(object sender, EventArgs e)
        {
            RegisterForm regForm = new RegisterForm();
            regForm.Show();
            this.Hide();
        }

        private void login_showpass_CheckedChanged(object sender, EventArgs e)
        {
            login_password.PasswordChar = login_showpass.Checked ? '\0' : '*';
        }

        public bool checkConnection()
        {
            return connect.State == ConnectionState.Closed;
        }

        private void Login_button_Click(object sender, EventArgs e)
        {
            if (checkConnection())
            {
                try
                {
                    connect.Open();

                    string selectRole = "SELECT role FROM users WHERE username = @usern AND password = @pass";

                    using (SqlCommand getRole = new SqlCommand(selectRole, connect))
                    {
                        getRole.Parameters.AddWithValue("@usern", login_username.Text.Trim());
                        getRole.Parameters.AddWithValue("@pass", login_password.Text.Trim());

                        string userRole = getRole.ExecuteScalar() as string;

                        if (!string.IsNullOrEmpty(userRole))
                        {
                            MessageBox.Show("Login successfully!", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            if (userRole == "Admin")
                            {
                                MainForm mform = new MainForm();
                                mform.Show();
                                this.Hide();
                            }
                            else if (userRole == "Cashier")
                            {
                                CashierMainForm cmform = new CashierMainForm();
                                cmform.Show();
                                this.Hide();
                            }
                        }
                        else
                        {
                            MessageBox.Show("Incorrect username/password or there's no Admin's approval",
                                            "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    connect.Close();
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }
    }
}
