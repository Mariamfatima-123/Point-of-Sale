﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    class OrdersData
    {
        SqlConnection connect
         = new SqlConnection(@"Data Source=DESKTOP-CVFUKU0\SQLEXPRESS01;
                                                                Initial Catalog=Stationary Shop;
                                                                Integrated Security=True;
                                                                Encrypt=False;");

       
        public string CID { set; get; }

        

        public string Product_Name { set; get; }

        public string Category { set; get; }

        public string OrigPrice { set; get; }

        public string QTY { set; get; }

        public string TotalPrice { set; get; }

        
       

        public List<OrdersData> allOrdersData()
        {
            List<OrdersData> listData = new List<OrdersData>();

            if (connect.State == ConnectionState.Closed)
            {
                try
                {
                    connect.Open();

                    int custID = 0;
                    string selectCustData = "SELECT MAX(customer_id) FROM orders";

                    using (SqlCommand cmd = new SqlCommand(selectCustData, connect))
                    {
                        object result = cmd.ExecuteScalar();

                        if (result != DBNull.Value && result != null)
                        {
                            custID = Convert.ToInt32(result);
                        }
                        else
                        {
                            Console.WriteLine("Error: No Customer ID found.");
                            return listData;
                        }
                    }

                    string selectData = "SELECT * FROM orders WHERE customer_id = @ID";

                    using (SqlCommand cmd = new SqlCommand(selectData, connect))
                    {
                        cmd.Parameters.AddWithValue("@ID", custID);
                        SqlDataReader reader = cmd.ExecuteReader();

                        while (reader.Read())
                        {
                            
                            OrdersData oData = new OrdersData();
                            oData.CID = reader["customer_id"].ToString();
                            
                            
                            oData.Product_Name = reader["prod_name"].ToString();
                            oData.Category = reader["category"].ToString();
                            oData.OrigPrice = reader["orig_price"].ToString(); 
                            oData.QTY = reader["qty"].ToString();
                            oData.TotalPrice = reader["total_price"].ToString();
                           
                            listData.Add(oData);
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Connection failed: " + ex);
                }
                finally
                {
                    connect.Close();
                }
            }

            return listData;
        }
    }
}


