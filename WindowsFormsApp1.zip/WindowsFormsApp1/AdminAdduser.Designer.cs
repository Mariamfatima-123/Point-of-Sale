﻿namespace WindowsFormsApp1
{
    partial class AdminAdduser
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel9 = new System.Windows.Forms.Panel();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.label12 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.addUsers_removeBtn = new System.Windows.Forms.Button();
            this.addUsers_deleteBtn = new System.Windows.Forms.Button();
            this.addUsers_updateBtn = new System.Windows.Forms.Button();
            this.addUsers_addBtn = new System.Windows.Forms.Button();
            this.addUsers_status = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.addUsers_role = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.addUsers_password = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.addUsers_username = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.panel10.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.White;
            this.panel9.Controls.Add(this.dataGridView2);
            this.panel9.Controls.Add(this.label12);
            this.panel9.Location = new System.Drawing.Point(279, 0);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(598, 638);
            this.panel9.TabIndex = 18;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Teal;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(16, 140);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(554, 456);
            this.dataGridView2.TabIndex = 13;
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(29, 89);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(212, 25);
            this.label12.TabIndex = 12;
            this.label12.Text = "All Users Information";
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.White;
            this.panel10.Controls.Add(this.addUsers_removeBtn);
            this.panel10.Controls.Add(this.addUsers_deleteBtn);
            this.panel10.Controls.Add(this.addUsers_updateBtn);
            this.panel10.Controls.Add(this.addUsers_addBtn);
            this.panel10.Controls.Add(this.addUsers_status);
            this.panel10.Controls.Add(this.label13);
            this.panel10.Controls.Add(this.addUsers_role);
            this.panel10.Controls.Add(this.label14);
            this.panel10.Controls.Add(this.addUsers_password);
            this.panel10.Controls.Add(this.label15);
            this.panel10.Controls.Add(this.addUsers_username);
            this.panel10.Controls.Add(this.label16);
            this.panel10.Location = new System.Drawing.Point(0, 0);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(273, 638);
            this.panel10.TabIndex = 17;
            // 
            // addUsers_removeBtn
            // 
            this.addUsers_removeBtn.BackColor = System.Drawing.Color.Teal;
            this.addUsers_removeBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.Teal;
            this.addUsers_removeBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Teal;
            this.addUsers_removeBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Teal;
            this.addUsers_removeBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addUsers_removeBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addUsers_removeBtn.ForeColor = System.Drawing.Color.White;
            this.addUsers_removeBtn.Location = new System.Drawing.Point(138, 491);
            this.addUsers_removeBtn.Name = "addUsers_removeBtn";
            this.addUsers_removeBtn.Size = new System.Drawing.Size(115, 50);
            this.addUsers_removeBtn.TabIndex = 11;
            this.addUsers_removeBtn.Text = "Clear";
            this.addUsers_removeBtn.UseVisualStyleBackColor = false;
            this.addUsers_removeBtn.Click += new System.EventHandler(this.addUsers_removeBtn_Click);
            // 
            // addUsers_deleteBtn
            // 
            this.addUsers_deleteBtn.BackColor = System.Drawing.Color.Teal;
            this.addUsers_deleteBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.Teal;
            this.addUsers_deleteBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Teal;
            this.addUsers_deleteBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Teal;
            this.addUsers_deleteBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addUsers_deleteBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addUsers_deleteBtn.ForeColor = System.Drawing.Color.White;
            this.addUsers_deleteBtn.Location = new System.Drawing.Point(11, 491);
            this.addUsers_deleteBtn.Name = "addUsers_deleteBtn";
            this.addUsers_deleteBtn.Size = new System.Drawing.Size(118, 50);
            this.addUsers_deleteBtn.TabIndex = 10;
            this.addUsers_deleteBtn.Text = "Delete";
            this.addUsers_deleteBtn.UseVisualStyleBackColor = false;
            this.addUsers_deleteBtn.Click += new System.EventHandler(this.addUsers_deleteBtn_Click);
            // 
            // addUsers_updateBtn
            // 
            this.addUsers_updateBtn.BackColor = System.Drawing.Color.Teal;
            this.addUsers_updateBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.Teal;
            this.addUsers_updateBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Teal;
            this.addUsers_updateBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Teal;
            this.addUsers_updateBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addUsers_updateBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addUsers_updateBtn.ForeColor = System.Drawing.Color.White;
            this.addUsers_updateBtn.Location = new System.Drawing.Point(135, 411);
            this.addUsers_updateBtn.Name = "addUsers_updateBtn";
            this.addUsers_updateBtn.Size = new System.Drawing.Size(118, 50);
            this.addUsers_updateBtn.TabIndex = 9;
            this.addUsers_updateBtn.Text = "Update";
            this.addUsers_updateBtn.UseVisualStyleBackColor = false;
            this.addUsers_updateBtn.Click += new System.EventHandler(this.addUsers_updateBtn_Click);
            // 
            // addUsers_addBtn
            // 
            this.addUsers_addBtn.BackColor = System.Drawing.Color.Teal;
            this.addUsers_addBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.Teal;
            this.addUsers_addBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Teal;
            this.addUsers_addBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Teal;
            this.addUsers_addBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addUsers_addBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addUsers_addBtn.ForeColor = System.Drawing.Color.White;
            this.addUsers_addBtn.Location = new System.Drawing.Point(12, 411);
            this.addUsers_addBtn.Name = "addUsers_addBtn";
            this.addUsers_addBtn.Size = new System.Drawing.Size(115, 50);
            this.addUsers_addBtn.TabIndex = 8;
            this.addUsers_addBtn.Text = "Add";
            this.addUsers_addBtn.UseVisualStyleBackColor = false;
            this.addUsers_addBtn.Click += new System.EventHandler(this.addUsers_addBtn_Click);
            // 
            // addUsers_status
            // 
            this.addUsers_status.FormattingEnabled = true;
            this.addUsers_status.Items.AddRange(new object[] {
            "Active",
            "Inactive",
            "Approval"});
            this.addUsers_status.Location = new System.Drawing.Point(24, 343);
            this.addUsers_status.Name = "addUsers_status";
            this.addUsers_status.Size = new System.Drawing.Size(208, 24);
            this.addUsers_status.TabIndex = 7;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(23, 305);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(61, 22);
            this.label13.TabIndex = 6;
            this.label13.Text = "Status";
            // 
            // addUsers_role
            // 
            this.addUsers_role.FormattingEnabled = true;
            this.addUsers_role.Items.AddRange(new object[] {
            "Admin",
            "Cashier"});
            this.addUsers_role.Location = new System.Drawing.Point(24, 261);
            this.addUsers_role.Name = "addUsers_role";
            this.addUsers_role.Size = new System.Drawing.Size(208, 24);
            this.addUsers_role.TabIndex = 5;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(23, 226);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(47, 22);
            this.label14.TabIndex = 4;
            this.label14.Text = "Role";
            // 
            // addUsers_password
            // 
            this.addUsers_password.Location = new System.Drawing.Point(24, 187);
            this.addUsers_password.Name = "addUsers_password";
            this.addUsers_password.Size = new System.Drawing.Size(211, 22);
            this.addUsers_password.TabIndex = 3;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(20, 151);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(89, 22);
            this.label15.TabIndex = 2;
            this.label15.Text = "Password";
            // 
            // addUsers_username
            // 
            this.addUsers_username.Location = new System.Drawing.Point(24, 111);
            this.addUsers_username.Name = "addUsers_username";
            this.addUsers_username.Size = new System.Drawing.Size(211, 22);
            this.addUsers_username.TabIndex = 1;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(20, 75);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(92, 22);
            this.label16.TabIndex = 0;
            this.label16.Text = "Username";
            // 
            // AdminAdduser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Teal;
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel10);
            this.Name = "AdminAdduser";
            this.Size = new System.Drawing.Size(880, 641);
            this.Load += new System.EventHandler(this.AdminAdduser_Load);
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Button addUsers_removeBtn;
        private System.Windows.Forms.Button addUsers_deleteBtn;
        private System.Windows.Forms.Button addUsers_updateBtn;
        private System.Windows.Forms.Button addUsers_addBtn;
        private System.Windows.Forms.ComboBox addUsers_status;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox addUsers_role;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox addUsers_password;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox addUsers_username;
        private System.Windows.Forms.Label label16;
    }
}
